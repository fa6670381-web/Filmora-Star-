package com.filmorastar.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    String active="Home";
    String[][] items={{"Movies","Jawan","Action • Hindi"},{"Movies","KGF Chapter 2","Action • Hindi"},{"Movies","Interstellar","Sci-Fi"},
    {"Series","Money Heist","Series"},{"Series","Mirzapur","Series • Hindi"},{"Series","Loki","Series"},
    {"Cartoons","Doraemon","Cartoon"},{"Cartoons","Shinchan","Cartoon"},{"Cartoons","Tom & Jerry","Cartoon"},
    {"Kids","Motu Patlu","Kids"},{"Kids","Chhota Bheem","Kids"},{"Kids","Paw Patrol","Kids"}};

    public void onCreate(Bundle b){super.onCreate(b); build();}
    TextView tv(String s,int size){ TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(18,12,18,12);return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(7,11,18));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=tv("Filmora ",22);TextView star=tv("Star ⭐",22);star.setTextColor(Color.rgb(255,23,79));
        bar.addView(logo);bar.addView(star); root.addView(bar,new LinearLayout.LayoutParams(-1,-2));
        HorizontalScrollView navScroll=new HorizontalScrollView(this); LinearLayout nav=new LinearLayout(this);
        String[] cats={"Home","Movies","Series","Cartoons","Kids"};
        for(String c:cats){Button x=new Button(this);x.setText(c);x.setTextColor(Color.WHITE);x.setBackground(bg(Color.rgb(17,25,39),40));x.setOnClickListener(v->{active=c;render();});nav.addView(x);}
        navScroll.addView(nav);root.addView(navScroll,new LinearLayout.LayoutParams(-1,60));
        ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(18,18,18,60);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);render();
    }
    void render(){
        content.removeAllViews();
        TextView hero=tv("STREAM YOUR WORLD\n\nMovies • Series • Cartoons • Kids\n\n▶  Watch Demo",28);
        hero.setTextColor(Color.WHITE);hero.setPadding(24,45,24,45);hero.setBackground(bg(Color.rgb(35,25,43),28));hero.setOnClickListener(v->Toast.makeText(this,"Demo player — add your licensed video here.",Toast.LENGTH_SHORT).show());
        content.addView(hero,new LinearLayout.LayoutParams(-1,260));
        String[] groups=active.equals("Home")?new String[]{"Movies","Series","Cartoons","Kids"}:new String[]{active};
        for(String group:groups){
            TextView h=tv(group,22);h.setPadding(4,25,4,12);content.addView(h);
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            for(String[] it:items) if(it[0].equals(group)){
                LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(5,5,5,5);
                TextView p=tv(it[1],16);p.setGravity(Gravity.CENTER);p.setBackground(bg(Color.rgb(35,54,80),20));
                card.addView(p,new LinearLayout.LayoutParams(210,170));
                TextView n=tv(it[2],12);n.setTextColor(Color.LTGRAY);card.addView(n);
                card.setOnClickListener(v->Toast.makeText(this,"Player: "+it[1],Toast.LENGTH_SHORT).show());
                row.addView(card,new LinearLayout.LayoutParams(220,220));
            }
            HorizontalScrollView hs=new HorizontalScrollView(this);hs.addView(row);content.addView(hs);
        }
    }
}