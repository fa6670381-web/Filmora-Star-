FILMORA STAR ANDROID STARTER PROJECT
Open this folder in Android Studio, sync Gradle, then Run on an Android device/emulator.
This starter contains the Filmora Star UI/navigation demo only.
It does not include copyrighted movies. Add only content you have rights to stream.
